
  # Academic Certificate Verification Website

  This is a code bundle for Academic Certificate Verification Website. The original project is available at https://www.figma.com/design/0WyPqNMRdku5EkYSDYJN07/Academic-Certificate-Verification-Website.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  